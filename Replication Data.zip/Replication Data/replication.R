library(ggplot2)     
library(dplyr)        
library(tidyverse)    
library(maps)         
library(broom)    
library(glmmTMB)
library(lme4)
library(stargazer)
library(jtools)

setwd("REPLICATION FOLDER")


#################################################
######### REGRESSIONS #############################
#################################################

full_dataset <- readRDS("main_data.rds")

full_dataset$year <- as.factor(full_dataset$year)

full_dataset$weight <- as.numeric(full_dataset$weight)


####### Main Regression

f1 <- formula(wtf ~ scale(log(y10moving_comb500+1))  + sex + scale(age) + year
              +(1 | ccode )
)


f2 <- formula(wtf ~  scale(log(y10moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))    + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)

f3 <- formula(wtf ~ scale(log(y10moving+1)) + sex + scale(age) + year
              +(1 | ccode )
)


f4 <- formula(wtf ~  scale(log(y10moving+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year 
               +(1 | ccode )
)

m1.1 <- glmer(f1, data = full_dataset, family = binomial(link="logit"))
m2.1 <- glmer(f2, data = full_dataset, family = binomial(link="logit"))
m3.1 <- glmer(f3, data = full_dataset, family = binomial(link="logit"))
m4.1 <- glmer(f4, data = full_dataset, family = binomial(link="logit"))

sd_m1 <- round(as.numeric(attributes(VarCorr(m1.1)$"ccode")$stddev), 3)
sd_m2 <- round(as.numeric(attributes(VarCorr(m2.1)$"ccode")$stddev), 3)             
sd_m3 <- round(as.numeric(attributes(VarCorr(m3.1)$"ccode")$stddev), 3)             
sd_m4 <- round(as.numeric(attributes(VarCorr(m4.1)$"ccode")$stddev), 3) 

K <- list( c("Number of countries", summary(m1.1)$ngrps,  summary(m2.1)$ngrps, summary(m3.1)$ngrps,  summary(m4.1)$ngrps),
           c("sd(Country)", sd_m1, sd_m2, sd_m3, sd_m4), c("Year Fixed Effect", "Yes", "Yes", "Yes" ,"Yes"))

stargazer(m1.1, m2.1, m3.1, m4.1, 
          title="Hierarchical logit regressions with random intercepts",
          out = "../Regression tables/main_regression_Y10_500km.html",
          align=TRUE,
          dep.var.labels = c("Willingness to fight"),
          covariate.labels=c("Log Conflict 500km", "Log Conflict", "Sex",
                             "Age", "Income level", "Pro Choice", 
                             "Confidence Military", "National Pride", "Log GDP p.c.", "Democracy Index",
                             "Conscription (Y/N)", "Defense Pact Non-US", "Defense Pact US", "War History", "Migrant Ratio"),
          add.lines=K,
          omit=c("year", "Constant"),
          omit.stat = c("aic", "bic"),
          label="wtf1",
          font.size = "tiny"
)






#################################################
######### Appendix #############################
#################################################


########
### 15 Year timeframe
#######

f1 <- formula(wtf ~ scale(log(y15moving_comb500+1))  + sex + scale(age) + year
              +(1 | ccode )
)


f2 <- formula(wtf ~  scale(log(y15moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))    + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)

f3 <- formula(wtf ~ scale(log(y15moving+1)) + sex + scale(age) + year
              +(1 | ccode )
)


f4 <- formula(wtf ~  scale(log(y15moving+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year 
              +(1 | ccode )
)


m1.1 <- glmmTMB(f1, data = full_dataset, family = binomial(link="logit"))
m2.1 <- glmmTMB(f2, data = full_dataset, family = binomial(link="logit"))
m3.1 <- glmmTMB(f3, data = full_dataset, family = binomial(link="logit"))
m4.1 <- glmmTMB(f4, data = full_dataset, family = binomial(link="logit"))


m1.1 <- glmer(f1, data = full_dataset, family = binomial(link="logit"))
m2.1 <- glmer(f2, data = full_dataset, family = binomial(link="logit"))
m3.1 <- glmer(f3, data = full_dataset, family = binomial(link="logit"))
m4.1 <- glmer(f4, data = full_dataset, family = binomial(link="logit"))

sd_m1 <- round(as.numeric(attributes(VarCorr(m1.1)$"ccode")$stddev), 3)
sd_m2 <- round(as.numeric(attributes(VarCorr(m2.1)$"ccode")$stddev), 3)             
sd_m3 <- round(as.numeric(attributes(VarCorr(m3.1)$"ccode")$stddev), 3)             
sd_m4 <- round(as.numeric(attributes(VarCorr(m4.1)$"ccode")$stddev), 3) 

K <- list( c("Number of countries", summary(m1.1)$ngrps,  summary(m2.1)$ngrps, summary(m3.1)$ngrps,  summary(m4.1)$ngrps),
           c("sd(Country)", sd_m1, sd_m2, sd_m3, sd_m4), c("Year Fixed Effect", "Yes", "Yes", "Yes" ,"Yes"))

stargazer(m1.1, m2.1, m3.1, m4.1, 
          title="Hierarchical logit regressions with random intercepts",
          out = "../Regression tables/main_regression_Y15_500km.html",
          align=TRUE,
          dep.var.labels = c("Willingness to fight"),
          covariate.labels=c("Log Conflict 500km", "Log Conflict", "Sex",
                             "Age", "Income level", "Pro Choice", 
                             "Confidence Military", "National Pride", "Log GDP p.c.", "Democracy Index",
                             "Conscription (Y/N)", "Defense Pact Non-US", "Defense Pact US", "War History", "Migrant Ratio"),
          add.lines=K,
          omit=c("year", "Constant"),
          omit.stat = c("aic", "bic"),
          label="wtf1",
          font.size = "tiny"
)





########
### 5 Year timeframe
#######

f1 <- formula(wtf ~ scale(log(y5moving_comb500+1))  + sex + scale(age) + year
              +(1 | ccode )
)


f2 <- formula(wtf ~  scale(log(y5moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))    + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)

f3 <- formula(wtf ~ scale(log(y5moving+1)) + sex + scale(age) + year
              +(1 | ccode )
)


f4 <- formula(wtf ~  scale(log(y5moving+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year 
              +(1 | ccode )
)


m1.1 <- glmer(f1, data = full_dataset, family = binomial(link="logit"))
m2.1 <- glmer(f2, data = full_dataset, family = binomial(link="logit"))
m3.1 <- glmer(f3, data = full_dataset, family = binomial(link="logit"))
m4.1 <- glmer(f4, data = full_dataset, family = binomial(link="logit"))

sd_m1 <- round(as.numeric(attributes(VarCorr(m1.1)$"ccode")$stddev), 3)
sd_m2 <- round(as.numeric(attributes(VarCorr(m2.1)$"ccode")$stddev), 3)             
sd_m3 <- round(as.numeric(attributes(VarCorr(m3.1)$"ccode")$stddev), 3)             
sd_m4 <- round(as.numeric(attributes(VarCorr(m4.1)$"ccode")$stddev), 3) 

K <- list( c("Number of countries", summary(m1.1)$ngrps,  summary(m2.1)$ngrps, summary(m3.1)$ngrps,  summary(m4.1)$ngrps),
           c("sd(Country)", sd_m1, sd_m2, sd_m3, sd_m4), c("Year Fixed Effect", "Yes", "Yes", "Yes" ,"Yes"))

stargazer(m1.1, m2.1, m3.1, m4.1, 
          title="Hierarchical logit regressions with random intercepts",
          out = "../Regression tables/main_regression_Y15_500km.html",
          align=TRUE,
          dep.var.labels = c("Willingness to fight"),
          covariate.labels=c("Log Conflict 500km", "Log Conflict", "Sex",
                             "Age", "Income level", "Pro Choice", 
                             "Confidence Military", "National Pride", "Log GDP p.c.", "Democracy Index",
                             "Conscription (Y/N)", "Defense Pact Non-US", "Defense Pact US", "War History", "Migrant Ratio"),
          add.lines=K,
          omit=c("year", "Constant"),
          omit.stat = c("aic", "bic"),
          label="wtf1",
          font.size = "tiny"
)




########
### Only interstate wars
#######

dataset_interstate <- readRDS("interstate.rds") ## Dataset that only includes interstate wars as the basis for constructing the main IVs

dataset_interstate$year <- as.factor(dataset_interstate$year)

f1 <- formula(wtf ~ scale(log(y10moving_comb500+1))  + sex + scale(age) + year
              +(1 | ccode )
)


f2 <- formula(wtf ~  scale(log(y10moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))    + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)

f3 <- formula(wtf ~ scale(log(y10moving+1)) + sex + scale(age) + year
              +(1 | ccode )
)


f4 <- formula(wtf ~  scale(log(y10moving+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year 
              +(1 | ccode )
)


m1.1_int <- glmer(f1, data = dataset_interstate, family = binomial(link="logit"))
m2.1_int <- glmer(f2, data = dataset_interstate, family = binomial(link="logit"))
m3.1_int <- glmer(f3, data = dataset_interstate, family = binomial(link="logit"))
m4.1_int <- glmer(f4, data = dataset_interstate, family = binomial(link="logit"))

sd_m1 <- round(as.numeric(attributes(VarCorr(m1.1_int)$"ccode")$stddev), 3)
sd_m2 <- round(as.numeric(attributes(VarCorr(m2.1_int)$"ccode")$stddev), 3)             
sd_m3 <- round(as.numeric(attributes(VarCorr(m3.1_int)$"ccode")$stddev), 3)             
sd_m4 <- round(as.numeric(attributes(VarCorr(m4.1_int)$"ccode")$stddev), 3) 

K <- list( c("Number of countries", summary(m1.1_int)$ngrps,  summary(m2.1_int)$ngrps, summary(m3.1_int)$ngrps,  summary(m4.1_int)$ngrps),
           c("sd(Country)", sd_m1, sd_m2, sd_m3, sd_m4), c("Year Fixed Effect", "Yes", "Yes", "Yes" ,"Yes"))

stargazer(m1.1_int, m2.1_int, m3.1_int, m4.1_int, 
          title="Hierarchical logit regressions with random intercepts",
          out = "../Regression tables/main_regression_Y10_500km_interstate.html",
          align=TRUE,
          dep.var.labels = c("Willingness to fight"),
          covariate.labels=c("Log Conflict 500km", "Log Conflict", "Sex",
                             "Age", "Income level", "Pro Choice", 
                             "Confidence Military", "National Pride", "Log GDP p.c.", "Democracy Index",
                             "Conscription (Y/N)", "Defense Pact Non-US", "Defense Pact US", "War History"),
          add.lines=K,
          omit=c("year", "Constant"),
          omit.stat = c("aic", "bic"),
          label="wtf1",
          font.size = "tiny"
)




########
### Survey weights
#######


f1 <- formula(wtf ~ scale(log(y10moving_comb500+1))  + sex + scale(age) + year
              +(1 | ccode )
)


f2 <- formula(wtf ~  scale(log(y10moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))   + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)

f3 <- formula(wtf ~ scale(log(y10moving+1)) + sex + scale(age) + year
              +(1 | ccode )
)


f4 <- formula(wtf ~  scale(log(y10moving+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year 
              +(1 | ccode )
)



m1.1_weight <- glmer(f1, data = full_dataset, family = binomial(link="logit"), weights = weight, nAGQ = 0)
m2.1_weight <- glmer(f2, data = full_dataset, family = binomial(link="logit"), weights = weight, nAGQ = 0)
m3.1_weight <- glmer(f3, data = full_dataset, family = binomial(link="logit"), weights = weight, nAGQ = 0)
m4.1_weight <- glmer(f4, data = full_dataset, family = binomial(link="logit"), weights = weight, nAGQ = 0)

sd_m1 <- round(as.numeric(attributes(VarCorr(m1.1_weight)$"ccode")$stddev), 3)
sd_m2 <- round(as.numeric(attributes(VarCorr(m2.1_weight)$"ccode")$stddev), 3)             
sd_m3 <- round(as.numeric(attributes(VarCorr(m3.1_weight)$"ccode")$stddev), 3)             
sd_m4 <- round(as.numeric(attributes(VarCorr(m4.1_weight)$"ccode")$stddev), 3) 

K <- list( c("Number of countries", summary(m1.1_weight)$ngrps,  summary(m2.1_weight)$ngrps, summary(m3.1_weight)$ngrps,  summary(m4.1_weight)$ngrps),
           c("sd(Country)", sd_m1, sd_m2, sd_m3, sd_m4), c("Year Fixed Effect", "Yes", "Yes", "Yes" ,"Yes"))

stargazer(m1.1_weight, m2.1_weight, m3.1_weight, m4.1_weight, 
          title="Hierarchical logit regressions with random intercepts",
          out = "../Regression tables/main_regression_Y10_500km_weights.html",
          align=TRUE,
          dep.var.labels = c("Willingness to fight"),
          covariate.labels=c("Log Conflict 500km", "Log Conflict", "Sex",
                             "Age", "Income level", "Pro Choice", 
                             "Confidence Military", "National Pride", "Log GDP p.c.", "Democracy Index",
                             "Conscription (Y/N)", "Defense Pact Non-US", "Defense Pact US", "War History"),
          add.lines=K,
          omit=c("year", "Constant"),
          omit.stat = c("aic", "bic"),
          label="wtf1",
          font.size = "tiny"
)




########
### Only democracies
#######

democracies <- full_dataset %>% filter(vdem_polyarchy>=0.7)


f1 <- formula(wtf ~ scale(log(y10moving_comb500+1))  + sex + scale(age) + year
              +(1 | ccode )
)


f2 <- formula(wtf ~  scale(log(y10moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)

f3 <- formula(wtf ~ scale(log(y10moving+1)) + sex + scale(age) + year
              +(1 | ccode )
)


f4 <- formula(wtf ~  scale(log(y10moving+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year 
              +(1 | ccode )
)


m1.1_dem <- glmer(f1, data = democracies, family = binomial(link="logit"))
m2.1_dem <- glmer(f2, data = democracies, family = binomial(link="logit"))
m3.1_dem <- glmer(f3, data = democracies, family = binomial(link="logit"))
m4.1_dem <- glmer(f4, data = democracies, family = binomial(link="logit"))


sd_m1 <- round(as.numeric(attributes(VarCorr(m1.1_dem)$"ccode")$stddev), 3)
sd_m2 <- round(as.numeric(attributes(VarCorr(m2.1_dem)$"ccode")$stddev), 3)             
sd_m3 <- round(as.numeric(attributes(VarCorr(m3.1_dem)$"ccode")$stddev), 3)             
sd_m4 <- round(as.numeric(attributes(VarCorr(m4.1_dem)$"ccode")$stddev), 3) 

K <- list( c("Number of countries", summary(m1.1_dem)$ngrps,  summary(m2.1_dem)$ngrps, summary(m3.1_dem)$ngrps,  summary(m4.1_dem)$ngrps),
           c("sd(Country)", sd_m1, sd_m2, sd_m3, sd_m4), c("Year Fixed Effect", "Yes", "Yes", "Yes" ,"Yes"))

stargazer(m1.1_dem, m2.1_dem, m3.1_dem, m4.1_dem, 
          title="Hierarchical logit regressions with random intercepts",
          out = "../Regression tables/main_regression_Y10_500km_democracies.html",
          align=TRUE,
          dep.var.labels = c("Willingness to fight"),
          covariate.labels=c("Log Conflict 500km", "Log Conflict", "Sex",
                             "Age", "Income level", "Pro Choice", 
                             "Confidence Military", "National Pride", "Log GDP p.c.",
                             "Conscription (Y/N)", "Defense Pact Non-US", "Defense Pact US", "War History"),
          add.lines=K,
          omit=c("year", "Constant"),
          omit.stat = c("aic", "bic"),
          label="wtf1",
          font.size = "tiny"
)


########
### Only under 30
#######


under_30 <- full_dataset %>% filter(full_dataset$age < 31)


f1 <- formula(wtf ~ scale(log(y10moving_comb500+1))  + sex + scale(age) + year
              +(1 | ccode )
)


f2 <- formula(wtf ~  scale(log(y10moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)

f3 <- formula(wtf ~ scale(log(y10moving+1)) + sex + scale(age) + year
              +(1 | ccode )
)


f4 <- formula(wtf ~  scale(log(y10moving+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))  + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year 
              +(1 | ccode )
)


m1.1_dem <- glmer(f1, data = under_30, family = binomial(link="logit"))
m2.1_dem <- glmer(f2, data = under_30, family = binomial(link="logit"))
m3.1_dem <- glmer(f3, data = under_30, family = binomial(link="logit"))
m4.1_dem <- glmer(f4, data = under_30, family = binomial(link="logit"))


sd_m1 <- round(as.numeric(attributes(VarCorr(m1.1_dem)$"ccode")$stddev), 3)
sd_m2 <- round(as.numeric(attributes(VarCorr(m2.1_dem)$"ccode")$stddev), 3)             
sd_m3 <- round(as.numeric(attributes(VarCorr(m3.1_dem)$"ccode")$stddev), 3)             
sd_m4 <- round(as.numeric(attributes(VarCorr(m4.1_dem)$"ccode")$stddev), 3) 

K <- list( c("Number of countries", summary(m1.1_dem)$ngrps,  summary(m2.1_dem)$ngrps, summary(m3.1_dem)$ngrps,  summary(m4.1_dem)$ngrps),
           c("sd(Country)", sd_m1, sd_m2, sd_m3, sd_m4), c("Year Fixed Effect", "Yes", "Yes", "Yes" ,"Yes"))

stargazer(m1.1_dem, m2.1_dem, m3.1_dem, m4.1_dem, 
          title="Hierarchical logit regressions with random intercepts",
          out = "../Regression tables/main_regression_Y10_500km_under30.html",
          align=TRUE,
          dep.var.labels = c("Willingness to fight"),
          covariate.labels=c("Log Conflict 500km", "Log Conflict", "Sex",
                             "Age", "Income level", "Pro Choice", 
                             "Confidence Military", "National Pride", "Log GDP p.c.",
                             "Conscription (Y/N)", "Defense Pact Non-US", "Defense Pact US", "War History"),
          add.lines=K,
          omit=c("year", "Constant"),
          omit.stat = c("aic", "bic"),
          label="wtf1",
          font.size = "tiny"
)






#################################################
######### DESCRIPTIVE STATISTICS #############################
#################################################


ivs_sub <- read_dta("ivs_sub.dta") ## Original EVS/WVS data; subset


##### Figure 1


## Subset for relevant columns
ivs_sub <- ivs_sub %>% filter(complete.cases(E012)) ## Filter out willingness to fight = NA


## Assign EVS Waves to WVS waves
ivs_sub$S002[ivs_sub$S002EVS==1] <- 1
ivs_sub$S002[ivs_sub$S002EVS==2] <- 2
ivs_sub$S002[ivs_sub$S002EVS==3] <- 4
ivs_sub$S002[ivs_sub$S002EVS==4] <- 6
ivs_sub$S002[ivs_sub$S002EVS==5] <- 7


## Iso3n country code to country names
ivs_sub$cname <- countrycode(ivs_sub$S003, "iso3n", "country.name")

ivs_sub$cname[ivs_sub$S003==909] <- "North Ireland"

ivs_sub <- ivs_sub %>%
  mutate(ing = if_else(cname %in% c("Bulgaria", "Estonia", "Chile", "Romania", "Ukraine", "Serbia", "Slovenia", "Nigeria", "Austria", "Moldova", "Lithuania", "Poland", "Spain", "South Korea", "Belarus",
                                    "Switzerland", "India", "China", "Brazil", "United States", "Australia", "Japan", "Uruguay", "United Kingdom", "Hungary", "Netherlands", "South Africa", "Germany", "New Zealand", 
                                    "Finland", "Canada", "Norway", "Sweden", "Mexico", "Russia", "Argentina", "Taiwan", "Turkey", "Italy", "France"), 1, 0))


filtered_data <- ivs_sub%>%
  filter(ing==1) %>%
  group_by(cname) %>%
  filter(S020<2010) %>%
  filter(max(S020)-min(S020) > 9) %>%
  ungroup()

change_data <- filtered_data %>%
  group_by(cname, S020, ing) %>%
  dplyr::summarize(Average = mean(E012, na.rm = TRUE)) %>%
  group_by(cname) %>%
  mutate(Change = last(Average) - first(Average)) %>%
  slice(1) %>% 
  ungroup()


## Standardize by years in dataset
change_data <- filtered_data %>%
  group_by(cname, S020, ing) %>%
  dplyr::summarize(Average = mean(E012, na.rm = TRUE), .groups = "drop_last") %>%
  group_by(cname) %>%
  mutate(Timespan_Years = last(S020) - first(S020), 
         Change_Per_Timespan = (last(Average) - first(Average)) / Timespan_Years) %>%
  slice(1) %>%
  ungroup()



ggplot(change_data, aes(x = reorder(cname, Change_Per_Timespan), y = Change_Per_Timespan, fill = cname)) +
  geom_bar(stat = "identity", fill="lightgrey") +
  theme_minimal() +
  labs(title = "Change in Willingness to Fight: 1981-2009",
       x = "Country",
       y = "Change in Willigness to Fight (Standardized)") +
  theme(
    legend.position = "none",
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, face="bold", size=12), 
    axis.text.y = element_text(size=12), 
    axis.title.x = element_text(size=18), 
    axis.title.y = element_text(size=18), 
    plot.title = element_text(size=20, face="bold") 
  )



















##### Figure 2


filtered_data <- ivs_sub%>%
  group_by(cname) %>%
  filter(max(S020)-min(S020) > 9) %>%
  ungroup()

## Standardize by years in dataset
change_data <- filtered_data %>%
  group_by(cname, S020, ing) %>%
  dplyr::summarize(Average = mean(E012, na.rm = TRUE), .groups = "drop_last") %>%
  group_by(cname) %>%
  mutate(Timespan_Years = last(S020) - first(S020), 
         Change_Per_Timespan = (last(Average) - first(Average)) / Timespan_Years) %>%
  slice(1) %>%
  ungroup()

ggplot(change_data, aes(x = reorder(cname, Change_Per_Timespan), y = Change_Per_Timespan, fill = ifelse(ing == 1, "blue", "grey"))) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("blue" = "lightblue", "grey" = "lightgrey"),
                    labels = c("Included in Inglehart et al.", "Not Included in Inglehart et al.")) +
  theme_minimal() +
  labs(title = "Change in Willingness to Fight: 1981-2023",
       x = "Country",
       y = "Change in Willingness to Fight (Standardized)") +
  theme(
    legend.position = "right",
    legend.title = element_blank(),
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5, face="bold", size=12), 
    axis.text.y = element_text(size=12), 
    axis.title.x = element_text(size=18), 
    axis.title.y = element_text(size=18), 
    plot.title = element_text(size=20, face="bold") 
  )























##### Figure 3

# Get the world map
world_map <- map("world", fill = TRUE, plot = FALSE)

# Convert the map
world_map_df <- tidy(world_map)

world_map_df <- world_map_df[world_map_df$region != "Antarctica",]

survey <- ivs_sub %>% select(S003, S020, S002) %>% distinct(S003, S020, .keep_all=T)

survey$cname <- countrycode(survey$S003, "iso3n", "country.name")

survey_counts <- survey %>% 
  group_by(cname) %>% 
  summarise(n_waves = n_distinct(S002))

# Change country names to match world map names

survey_counts$cname[survey_counts$cname=="United States"] <- "USA"
survey_counts$cname[survey_counts$cname=="United Kingdom"] <- "UK"
survey_counts$cname[survey_counts$cname=="Bosnia & Herzegovina"] <- "Bosnia and Herzegovina"
survey_counts$cname[survey_counts$cname=="Czechia"] <- "Czech Republic"
survey_counts$cname[survey_counts$cname=="Myanmar (Burma)"] <- "Myanmar"
survey_counts$cname[survey_counts$cname=="Trinidad & Tobago"] <- "Trinidad"


# Merge world_map_df with survey_counts
world_map_ivs <- left_join(world_map_df, survey_counts, by = c("region" = "cname"))

# Add a column to differentiate the groups
world_map_ivs$highlight <- ifelse(is.na(world_map_ivs$n_waves), "No Participation",
                                  ifelse(world_map_ivs$n_waves == 1, "One Wave",
                                         ifelse(world_map_ivs$n_waves > 1 & world_map_ivs$n_waves < 7, "One+ Waves", "All Waves")))

world_map_ivs$highlight <- factor(world_map_ivs$highlight, 
                                  levels = c("No Participation", "One Wave", "One+ Waves", "All Waves"))

# Plot the map
ggplot(data = world_map_ivs) +
  geom_polygon(aes(x = long, y = lat, fill = highlight, group = group)) +
  scale_fill_manual(values = c("No Participation" = "grey80", "One Wave" = "lightblue", "One+ Waves" = "darkblue", "All Waves"="orange3")) +
  theme_minimal() +
  theme(legend.position = "bottom", legend.text=element_text(size = 22)) +
  labs(fill = "", title = "") +
  theme(axis.line=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks=element_blank(),
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        panel.background=element_blank(),
        panel.border=element_blank(),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        plot.background=element_blank())
























### Figure 4

full_dataset <- readRDS("main_data.rds")


## Calculate regional average
region_df <- full_dataset %>% select(ccode, year, wtf) %>%  filter(complete.cases(wtf))

region_df$region <- countrycode(sourcevar = region_df$ccode,
                                origin = "cown",
                                destination = "continent")

region_df$region[region_df$ccode==315] <- "Eastern Europe"
region_df$region[region_df$ccode==345] <- "Eastern Europe"

region_df$region[region_df$ccode==260] <- "Western Europe"
region_df$region[region_df$ccode==255] <- "Western Europe"
region_df$region[region_df$ccode==305] <- "Western Europe"
region_df$region[region_df$ccode==211] <- "Western Europe"
region_df$region[region_df$ccode==211] <- "Western Europe"
region_df$region[region_df$ccode==352] <- "Western Europe"
region_df$region[region_df$ccode==390] <- "Western Europe"
region_df$region[region_df$ccode==375] <- "Western Europe"
region_df$region[region_df$ccode==220] <- "Western Europe"
region_df$region[region_df$ccode==350] <- "Western Europe"
region_df$region[region_df$ccode==395] <- "Western Europe"
region_df$region[region_df$ccode==205] <- "Western Europe"
region_df$region[region_df$ccode==325] <- "Western Europe"
region_df$region[region_df$ccode==212] <- "Western Europe"
region_df$region[region_df$ccode==338] <- "Western Europe"
region_df$region[region_df$ccode==210] <- "Western Europe"
region_df$region[region_df$ccode==385] <- "Western Europe"
region_df$region[region_df$ccode==235] <- "Western Europe"
region_df$region[region_df$ccode==230] <- "Western Europe"
region_df$region[region_df$ccode==380] <- "Western Europe"
region_df$region[region_df$ccode==225] <- "Western Europe"
region_df$region[region_df$ccode==200] <- "Western Europe"
region_df$region[region_df$region=="Europe"] <- "Eastern Europe"

region_df$region[region_df$ccode==615] <- "North Africa"
region_df$region[region_df$ccode==651] <- "North Africa"
region_df$region[region_df$ccode==620] <- "North Africa"
region_df$region[region_df$ccode==600] <- "North Africa"
region_df$region[region_df$ccode==616] <- "North Africa"
region_df$region[region_df$region=="Africa"] <- "Sub-Sah. Africa"


region_df$region[region_df$ccode==20] <- "North America"
region_df$region[region_df$ccode==2] <- "North America"
region_df$region[region_df$region=="Americas"] <- "Latin America"

region_df <- region_df %>%
  group_by(region, wtf) %>%
  summarise(Count = n()) %>%
  mutate(Percentage = Count / sum(Count) * 100)

region_df_yes <- region_df[region_df$wtf == 1,]
region_df_yes$wtf <- "Yes"


region_df_yes$region <- reorder(region_df_yes$region, -region_df_yes$Percentage)


# Calculate global average
global_avg <- full_dataset %>%
  filter(wtf == 1) %>%
  filter(complete.cases(wtf)) %>%
  summarise(Count = n())

filtered_full <- full_dataset %>% filter(complete.cases(wtf))

global_percentage <- global_avg$Count / nrow(filtered_full) * 100

# Create a dataframe for the global average
global_df <- data.frame(region = "Global", 
                        wtf = "Yes", 
                        Count = global_avg$Count, 
                        Percentage = global_percentage)

# Combine global average with regional averages
combined_df <- rbind(global_df, region_df_yes)

# Order combined data for plotting
desired_order <- c("Global", "North Africa", "Asia", "Eastern Europe", "Sub-Sah. Africa", 
                   "Latin America", "Oceania", "North America", "Western Europe")

# Set the factor levels
combined_df$region <- factor(combined_df$region, levels = desired_order)


# Generate the combined bar plot
ggplot(combined_df, aes(x = region, y = Percentage)) +
  geom_bar(stat = "identity", fill = "darkblue") +
  geom_text(aes(label = paste0(round(Percentage, 1), "%")), vjust = -0.5, size = 6) +
  labs(x = "Region", y = "Percentage", 
       title = "Percentage of 'Yes' Answers Globally and by Region") +
  theme_minimal() +
  theme(text = element_text(size = 23),
        axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank())








### Figure 5: Power point annotations to the map























### Figure 6


# Select and add region information
region_df <- full_dataset %>% select(ccode, year, y10moving_min500, y10moving_int500) %>% filter(complete.cases(y10moving_min500)) %>% distinct(ccode, year, .keep_all=T) 

region_df$region <- countrycode(sourcevar = region_df$ccode,
                                origin = "cown",
                                destination = "continent")

region_df$region[region_df$ccode==315] <- "Eastern Europe"
region_df$region[region_df$ccode==345] <- "Eastern Europe"

region_df$region[region_df$ccode==260] <- "Western Europe"
region_df$region[region_df$ccode==255] <- "Western Europe"
region_df$region[region_df$ccode==305] <- "Western Europe"
region_df$region[region_df$ccode==211] <- "Western Europe"
region_df$region[region_df$ccode==211] <- "Western Europe"
region_df$region[region_df$ccode==352] <- "Western Europe"
region_df$region[region_df$ccode==390] <- "Western Europe"
region_df$region[region_df$ccode==375] <- "Western Europe"
region_df$region[region_df$ccode==220] <- "Western Europe"
region_df$region[region_df$ccode==350] <- "Western Europe"
region_df$region[region_df$ccode==395] <- "Western Europe"
region_df$region[region_df$ccode==205] <- "Western Europe"
region_df$region[region_df$ccode==325] <- "Western Europe"
region_df$region[region_df$ccode==212] <- "Western Europe"
region_df$region[region_df$ccode==338] <- "Western Europe"
region_df$region[region_df$ccode==210] <- "Western Europe"
region_df$region[region_df$ccode==385] <- "Western Europe"
region_df$region[region_df$ccode==235] <- "Western Europe"
region_df$region[region_df$ccode==230] <- "Western Europe"
region_df$region[region_df$ccode==380] <- "Western Europe"
region_df$region[region_df$ccode==225] <- "Western Europe"
region_df$region[region_df$ccode==200] <- "Western Europe"
region_df$region[region_df$region=="Europe"] <- "Eastern Europe"

region_df$region[region_df$ccode==615] <- "North Africa"
region_df$region[region_df$ccode==651] <- "North Africa"
region_df$region[region_df$ccode==620] <- "North Africa"
region_df$region[region_df$ccode==600] <- "North Africa"
region_df$region[region_df$ccode==616] <- "North Africa"
region_df$region[region_df$region=="Africa"] <- "Sub-Sah. Africa"


region_df$region[region_df$ccode==20] <- "North America"
region_df$region[region_df$ccode==2] <- "North America"
region_df$region[region_df$region=="Americas"] <- "Latin America"

region_df_melt <- melt(region_df, id.vars = c("ccode", "year", "region"), variable.name = "conflict_type", value.name = "number_of_conflicts")

# Rename conflict_type levels
region_df_melt$conflict_type <- recode(region_df_melt$conflict_type,
                                       "y10moving_min500" = "Minor conflict",
                                       "y10moving_int500" = "War")

region_df_melt$region <- factor(region_df_melt$region, levels = c("Asia", "North Africa", "Eastern Europe", "Sub-Sah. Africa", "Latin America", "Western Europe", "North America", "Oceania"))

# ggplot
ggplot(region_df_melt, aes(x = region, y = number_of_conflicts, fill = conflict_type)) +
  geom_violin(scale = "width", position = position_dodge(width = 0.9), width = 0.9) + 
  labs(x = "Region", y = "Sum of Conflicts (10 Year Moving)", 
       title = "Distribution of Conflicts within 500 KM of a Country") +
  scale_fill_discrete(name = "Conflict Intensity",
                      breaks = c("Minor conflict", "War")) +
  scale_fill_manual(name = "Conflict Intensity",
                    values = c("Minor conflict" = "lightblue", "War" = "darkblue")) +
  theme_minimal() +
  theme(text = element_text(size = 24),
        axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))



























### Figure 7


df <- full_dataset %>% 
  select(ccode, year, y10moving_comb500, wtf) %>% 
  filter(complete.cases(wtf)) %>%
  group_by(ccode, year) %>% 
  mutate(percentage = mean(wtf)) %>%
  distinct(ccode, year, .keep_all = T)

# Create levels based on count variable
df$count_levels <- cut(df$y10moving_comb500, breaks = quantile(df$y10moving_comb500, probs = 0:3/3), labels = c("low", "medium", "high"), include.lowest = TRUE)

# Plotting
ggplot(df, aes(x = count_levels, y = percentage)) +
  geom_boxplot() +
  labs(x = "Proximate conflicts: Aggregate sum of past 10 Years", y = "Proportion of Yes (Willingness to Fight)", title = "Willingness to Fight and Proximate Conflicts by Country-Year") +
  theme_minimal() + 
  theme(text = element_text(size = 24),
        axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))























### Figure 8 

corr_plot <- full_dataset %>%  group_by(ccode, year) %>% filter(complete.cases(wtf)) %>% mutate(mean=mean(wtf)) %>% distinct(ccode, year, .keep_all=T) %>% select(ccode, year, mean, y10moving_comb500)

# Calculate the common y-axis limits
y_limits <- range(corr_plot$y10moving_comb500, na.rm = TRUE)

# First plot
p1 <- ggplot(corr_plot, aes(x=mean, y=y10moving_comb500)) +
  geom_point() + 
  geom_smooth(method="loess", se=T, color="blue") +
  theme_minimal() + 
  labs(y="Sum of Proximate Conflicts", x="Mean Willingness to Fight (Country-Year)", subtitle="Loess Fit") + 
  theme(
    text = element_text(size = 23), 
    axis.title.y=element_text(angle=90, vjust=2.5)) +
  coord_cartesian(ylim = y_limits) 

# Second plot
p2 <- ggplot(corr_plot, aes(x=mean, y=y10moving_comb500)) +
  geom_point() + 
  geom_smooth(method="lm", se=T, color="blue") +
  theme_minimal() + 
  labs(y="", x="Mean Willingness to Fight (Country-Year)", subtitle="Linear Regression") + 
  theme(
    text = element_text(size = 23), 
    axis.title.y=element_blank(),
    axis.text.y=element_blank(),
    axis.ticks.y=element_blank()) +
  coord_cartesian(ylim = y_limits) 

combined_plot <- p1 + p2 + plot_layout(ncol=2) + 
  plot_annotation(
    title="Relationship: Proximate Conflicts and Willingness to Fight", 
    subtitle="", 
    caption="")

combined_plot & theme(plot.title = element_text(size = 28))








### Figure 8 

full_dataset <- readRDS("main_data.rds")

full_dataset$year <- as.factor(full_dataset$year)

full_dataset$weight <- as.numeric(full_dataset$weight)


f2 <- formula(wtf ~  scale(log(y10moving_comb500+1)) + sex + scale(age) + scale(income_lvl) + scale(pro_choice_pca.imp) + scale(conf_military) + scale(national_pride) 
              + scale(log(gdpcon2015+1))    + scale(vdem_polyarchy)   + scale(conscription) + defense_pact_nonus + defense_pact_us + atwar_main_timedisc + year
              +(1 | ccode )
)


m2.1 <- glmer(f2, data = full_dataset, family = binomial(link="logit"))


p <- effect_plot(m2.1, pred = y10moving_comb500, interval = TRUE, y.label = "Willingness to Fight", 
                 x.label="Proximate conflict score (500 km)", partial.residuals=F)

p + scale_y_continuous(breaks = seq(from = 0, to = 9, by = 0.05)) +
  theme(text = element_text(size=20))



